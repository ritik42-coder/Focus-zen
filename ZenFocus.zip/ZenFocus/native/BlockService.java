package com.zenfocus.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Watches the foreground app and covers it with a full-screen overlay when a daily
 * limit is spent or when student mode blocks it. Runs as a foreground service.
 */
public class BlockService extends Service {

    public static final String ACTION_START = "com.zenfocus.app.GUARD_START";
    public static final String ACTION_STOP = "com.zenfocus.app.GUARD_STOP";
    public static final String EXTRA_LIMITS = "limits";        // {"pkg": minutes}
    public static final String EXTRA_STRICT = "strict";        // {"pkg": untilMs}
    public static final String EXTRA_STUDENT = "student";      // boolean
    public static final String EXTRA_UNTIL = "studentUntil";   // long
    public static final String EXTRA_ALLOW = "allow";          // ["pkg", ...]
    public static final String EXTRA_BLOCK = "block";          // ["pkg", ...]

    private static final String CHANNEL = "zenfocus_guard";
    private static final int NOTIF_ID = 4201;

    private Handler handler;
    private Runnable ticker;
    private WindowManager wm;
    private View overlay;
    private String overlayKey = "";

    private final Map<String, Integer> limits = new HashMap<>();
    private final Map<String, Long> strict = new HashMap<>();
    private final Map<String, Long> graceUntil = new HashMap<>();
    private final List<String> allow = new ArrayList<>();
    private final Set<String> block = new HashSet<>();
    private boolean studentMode = false;
    private long studentUntil = 0L;

    private long lastUsageCheck = 0L;
    private long cachedUsage = 0L;
    private String cachedPkg = "";

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            shutdown();
            return START_NOT_STICKY;
        }
        if (intent != null) readConfig(intent);
        startForegroundSafely();
        startLoop();
        return START_STICKY;
    }

    /* ---------------- configuration ---------------- */

    private void readConfig(Intent intent) {
        limits.clear();
        strict.clear();
        allow.clear();
        block.clear();
        studentMode = intent.getBooleanExtra(EXTRA_STUDENT, false);
        studentUntil = intent.getLongExtra(EXTRA_UNTIL, 0L);

        try {
            String j = intent.getStringExtra(EXTRA_LIMITS);
            if (j != null) {
                JSONObject o = new JSONObject(j);
                Iterator<String> it = o.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    limits.put(k, o.optInt(k, 0));
                }
            }
        } catch (Exception ignored) {}

        try {
            String j = intent.getStringExtra(EXTRA_STRICT);
            if (j != null) {
                JSONObject o = new JSONObject(j);
                Iterator<String> it = o.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    strict.put(k, o.optLong(k, 0L));
                }
            }
        } catch (Exception ignored) {}

        try {
            String j = intent.getStringExtra(EXTRA_ALLOW);
            if (j != null) {
                JSONArray a = new JSONArray(j);
                for (int i = 0; i < a.length(); i++) allow.add(a.getString(i));
            }
        } catch (Exception ignored) {}

        try {
            String j = intent.getStringExtra(EXTRA_BLOCK);
            if (j != null) {
                JSONArray a = new JSONArray(j);
                for (int i = 0; i < a.length(); i++) block.add(a.getString(i));
            }
        } catch (Exception ignored) {}

        // A limit that is now strict must never keep a leftover break window.
        for (String pkg : new ArrayList<>(graceUntil.keySet())) {
            if (isStrict(pkg)) graceUntil.remove(pkg);
        }
        // Force the overlay to be rebuilt with the new rules.
        if (overlay != null) hideOverlay();
    }

    private void startForegroundSafely() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26 && nm != null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Limit guard",
                        NotificationManager.IMPORTANCE_MIN);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, CHANNEL)
                    : new Notification.Builder(this);
            b.setContentTitle("Zen Focus")
             .setContentText(studentMode ? "Student mode is on" : "Watching your daily limits")
             .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
             .setOngoing(true);
            if (Build.VERSION.SDK_INT >= 21) b.setColor(0xFF6C7CFF);
            startForeground(NOTIF_ID, b.build());
        } catch (Exception ignored) {}
    }

    private void startLoop() {
        if (ticker != null) handler.removeCallbacks(ticker);
        ticker = new Runnable() {
            @Override
            public void run() {
                try {
                    check();
                } catch (Exception ignored) {}
                handler.postDelayed(this, 1000);
            }
        };
        handler.postDelayed(ticker, 500);
    }

    /* ---------------- state helpers ---------------- */

    private boolean isStrict(String pkg) {
        Long until = strict.get(pkg);
        if (until == null) return false;
        return until == 0L || System.currentTimeMillis() < until;
    }

    private boolean studentActive() {
        if (!studentMode) return false;
        return studentUntil == 0L || System.currentTimeMillis() < studentUntil;
    }

    private String foregroundPackage() {
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return "";
            long now = System.currentTimeMillis();
            UsageEvents ev = usm.queryEvents(now - 8000, now);
            if (ev == null) return "";
            UsageEvents.Event e = new UsageEvents.Event();
            String last = "";
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED) {
                    last = e.getPackageName();
                }
            }
            return last == null ? "" : last;
        } catch (Exception e) {
            return "";
        }
    }

    private long usedToday(String pkg) {
        long now = System.currentTimeMillis();
        if (pkg.equals(cachedPkg) && now - lastUsageCheck < 8000) return cachedUsage;
        long used = 0L;
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm != null) {
                Calendar c = Calendar.getInstance();
                c.set(Calendar.HOUR_OF_DAY, 0);
                c.set(Calendar.MINUTE, 0);
                c.set(Calendar.SECOND, 0);
                c.set(Calendar.MILLISECOND, 0);
                Map<String, UsageStats> map = usm.queryAndAggregateUsageStats(c.getTimeInMillis(), now);
                UsageStats s = map.get(pkg);
                if (s != null) used = s.getTotalTimeInForeground();
            }
        } catch (Exception ignored) {}
        cachedPkg = pkg;
        cachedUsage = used;
        lastUsageCheck = now;
        return used;
    }

    /* ---------------- the watch loop ---------------- */

    private void check() {
        if (!Settings.canDrawOverlays(this)) return;
        String pkg = foregroundPackage();
        if (pkg.isEmpty()) return;
        if (pkg.equals(getPackageName())) {
            hideOverlay();
            return;
        }

        if (studentActive() && block.contains(pkg)) {
            showStudentOverlay(pkg);
            return;
        }

        Integer limit = limits.get(pkg);
        if (limit == null || limit <= 0) {
            hideOverlay();
            return;
        }
        Long grace = graceUntil.get(pkg);
        if (grace != null && System.currentTimeMillis() < grace) {
            hideOverlay();
            return;
        }
        long used = usedToday(pkg);
        if (used >= limit * 60000L) {
            showLimitOverlay(pkg, used, limit, isStrict(pkg));
        } else {
            hideOverlay();
        }
    }

    /* ---------------- overlays ---------------- */

    private void attach(View root, String key) {
        try {
            int type = Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    android.graphics.PixelFormat.OPAQUE);
            lp.gravity = Gravity.CENTER;
            wm.addView(root, lp);
            overlay = root;
            overlayKey = key;
        } catch (Exception ignored) {
            overlay = null;
            overlayKey = "";
        }
    }

    private LinearLayout baseOverlay() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(0xF70B0B0D);
        int pad = dp(26);
        root.setPadding(pad, pad, pad, pad);
        return root;
    }

    private void showLimitOverlay(final String pkg, long used, int limitMin, final boolean strictMode) {
        String key = "L:" + pkg + ":" + (strictMode ? "1" : "0");
        if (overlay != null && key.equals(overlayKey)) return;
        hideOverlay();
        try {
            LinearLayout root = baseOverlay();

            ImageView icon = new ImageView(this);
            try {
                icon.setImageDrawable(getPackageManager().getApplicationIcon(pkg));
            } catch (Exception ignored) {}
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(72), dp(72));
            ip.bottomMargin = dp(20);
            root.addView(icon, ip);

            root.addView(title("Time's up"));

            TextView sub = new TextView(this);
            sub.setText(label(pkg) + " · " + limitMin + " min limit reached\n"
                    + (used / 60000L) + " min used today");
            sub.setTextColor(0xFF8C8E9A);
            sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            sub.setGravity(Gravity.CENTER);
            sub.setLineSpacing(dp(4), 1f);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            sp.topMargin = dp(10);
            sp.bottomMargin = dp(28);
            root.addView(sub, sp);

            if (!strictMode) {
                TextView later = button("Take a 5 minute break", false);
                later.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // never grant a break on a strict limit
                        if (isStrict(pkg)) {
                            hideOverlay();
                            return;
                        }
                        graceUntil.put(pkg, System.currentTimeMillis() + 5 * 60000L);
                        hideOverlay();
                    }
                });
                root.addView(later, buttonParams());
            }

            TextView close = button(strictMode ? "Close and take a break" : "Close app", true);
            close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goHome();
                }
            });
            root.addView(close, buttonParams());

            if (strictMode) {
                TextView note = new TextView(this);
                note.setText("Strict mode is on — this limit can't be changed");
                note.setTextColor(0xFF63656F);
                note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                note.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                np.topMargin = dp(16);
                root.addView(note, np);
            }

            attach(root, key);
        } catch (Exception ignored) {
            overlay = null;
        }
    }

    private void showStudentOverlay(String pkg) {
        String key = "S:" + pkg + ":" + allow.size();
        if (overlay != null && key.equals(overlayKey)) return;
        hideOverlay();
        try {
            LinearLayout root = baseOverlay();

            TextView badge = new TextView(this);
            badge.setText("STUDENT MODE");
            badge.setTextColor(0xFF6C7CFF);
            badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            badge.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            badge.setLetterSpacing(0.12f);
            badge.setGravity(Gravity.CENTER);
            root.addView(badge);

            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            tp.topMargin = dp(8);
            tp.bottomMargin = dp(6);
            TextView t = title("Study time");
            root.addView(t, tp);

            TextView sub = new TextView(this);
            sub.setText(label(pkg) + " is paused until student mode ends.\nThese apps still work:");
            sub.setTextColor(0xFF8C8E9A);
            sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            sub.setGravity(Gravity.CENTER);
            sub.setLineSpacing(dp(4), 1f);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            sp.bottomMargin = dp(22);
            root.addView(sub, sp);

            root.addView(appGrid());

            TextView manage = button("Manage in Zen Focus", false);
            manage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openSelf();
                }
            });
            LinearLayout.LayoutParams mp = buttonParams();
            mp.topMargin = dp(20);
            root.addView(manage, mp);

            attach(root, key);
        } catch (Exception ignored) {
            overlay = null;
        }
    }

    private LinearLayout appGrid() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        LinearLayout row = null;
        int perRow = 3;
        int shown = 0;
        for (String p : allow) {
            if (shown >= 9) break;
            Intent li = getPackageManager().getLaunchIntentForPackage(p);
            if (li == null) continue;
            if (row == null || shown % perRow == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER);
                wrap.addView(row);
            }
            row.addView(appCell(p));
            shown++;
        }
        return wrap;
    }

    private LinearLayout appCell(final String pkg) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER);
        cell.setPadding(dp(8), dp(10), dp(8), dp(10));

        ImageView iv = new ImageView(this);
        try {
            iv.setImageDrawable(getPackageManager().getApplicationIcon(pkg));
        } catch (Exception ignored) {}
        cell.addView(iv, new LinearLayout.LayoutParams(dp(44), dp(44)));

        TextView tv = new TextView(this);
        tv.setText(label(pkg));
        tv.setTextColor(0xFFF2F3F7);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setGravity(Gravity.CENTER);
        tv.setMaxLines(1);
        tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(84),
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        cell.addView(tv, lp);

        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchApp(pkg);
            }
        });
        return cell;
    }

    /* ---------------- small view helpers ---------------- */

    private TextView title(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 29);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private String label(String pkg) {
        try {
            return String.valueOf(getPackageManager().getApplicationLabel(
                    getPackageManager().getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(250), dp(52));
        p.bottomMargin = dp(12);
        return p;
    }

    private TextView button(String text, boolean primary) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        v.setGravity(Gravity.CENTER);
        v.setTextColor(primary ? 0xFF0B0B0D : Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(primary ? 0xFF6C7CFF : 0xFF1D1D23);
        v.setBackground(bg);
        return v;
    }

    private void launchApp(String pkg) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            hideOverlay();
        } catch (Exception ignored) {}
    }

    private void openSelf() {
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            hideOverlay();
        } catch (Exception ignored) {}
    }

    private void goHome() {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {}
    }

    private void hideOverlay() {
        if (overlay == null) return;
        try {
            wm.removeView(overlay);
        } catch (Exception ignored) {}
        overlay = null;
        overlayKey = "";
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }

    private void shutdown() {
        if (ticker != null) handler.removeCallbacks(ticker);
        hideOverlay();
        try {
            stopForeground(true);
        } catch (Exception ignored) {}
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (ticker != null) handler.removeCallbacks(ticker);
        hideOverlay();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
