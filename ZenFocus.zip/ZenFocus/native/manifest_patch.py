#!/usr/bin/env python3
"""Patches the generated AndroidManifest.xml for Zen Focus.

Kept inside the project so the build workflow never has to change again:
permissions, the guard service and the widget receiver are all added here.
"""
import os
import sys

MANIFEST = os.path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml')

PERMISSIONS = [
    'android.permission.PACKAGE_USAGE_STATS',
    'android.permission.ACCESS_NOTIFICATION_POLICY',
    'android.permission.SYSTEM_ALERT_WINDOW',
    'android.permission.FOREGROUND_SERVICE',
    'android.permission.FOREGROUND_SERVICE_SPECIAL_USE',
    'android.permission.POST_NOTIFICATIONS',
    'android.permission.RECEIVE_BOOT_COMPLETED',
]

SERVICE = (
    '<service android:name=".BlockService" android:exported="false" '
    'android:foregroundServiceType="specialUse">\n'
    '            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" '
    'android:value="Screen time limit enforcement"/>\n'
    '        </service>\n    '
)

RECEIVERS = [
    ('WidgetProvider', 'widget_info'),
    ('LimitsWidgetProvider', 'widget_limits_info'),
]


def receiver(name, info):
    return (
        '<receiver android:name=".%s" android:exported="false">\n'
        '            <intent-filter>\n'
        '                <action android:name="android.appwidget.action.APPWIDGET_UPDATE"/>\n'
        '            </intent-filter>\n'
        '            <meta-data android:name="android.appwidget.provider" '
        'android:resource="@xml/%s"/>\n'
        '        </receiver>\n    ' % (name, info)
    )


def main():
    if not os.path.exists(MANIFEST):
        sys.exit('AndroidManifest.xml not found at ' + MANIFEST)
    s = open(MANIFEST).read()

    missing = [p for p in PERMISSIONS if p not in s]
    if missing:
        block = ''.join('<uses-permission android:name="%s"/>\n    ' % p for p in missing)
        s = s.replace('<application', block + '<application', 1)

    if 'BlockService' not in s:
        s = s.replace('</application>', SERVICE + '</application>', 1)

    for name, info in RECEIVERS:
        if name not in s:
            s = s.replace('</application>', receiver(name, info) + '</application>', 1)

    open(MANIFEST, 'w').write(s)
    print('manifest patched (%d new permissions)' % len(missing))


if __name__ == '__main__':
    main()
