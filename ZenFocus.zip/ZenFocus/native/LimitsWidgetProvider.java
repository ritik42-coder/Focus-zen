package com.zenfocus.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** Home screen widget: how close each limited app is to its budget. */
public class LimitsWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            try {
                manager.updateAppWidget(id, build(context));
            } catch (Exception ignored) {}
        }
    }

    public static void updateAll(Context context) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(context);
            ComponentName n = new ComponentName(context, LimitsWidgetProvider.class);
            int[] ids = m.getAppWidgetIds(n);
            for (int id : ids) m.updateAppWidget(id, build(context));
        } catch (Exception ignored) {}
    }

    static RemoteViews build(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_limits);

        JSONObject limits = new JSONObject();
        try {
            String json = c.getSharedPreferences("zenfocus", Context.MODE_PRIVATE).getString("state", "");
            if (json != null && json.length() > 0) {
                limits = new JSONObject(json).optJSONObject("limits");
            }
        } catch (Exception ignored) {}
        if (limits == null) limits = new JSONObject();

        List<String[]> rows = new ArrayList<>();   // {pkg, usedMs, limitMin}
        try {
            UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm != null && limits.length() > 0) {
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, 0);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                Map<String, UsageStats> map =
                        usm.queryAndAggregateUsageStats(cal.getTimeInMillis(), System.currentTimeMillis());
                java.util.Iterator<String> it = limits.keys();
                while (it.hasNext()) {
                    String pkg = it.next();
                    int limit = limits.optInt(pkg, 0);
                    if (limit <= 0) continue;
                    UsageStats s = map.get(pkg);
                    long used = s == null ? 0L : s.getTotalTimeInForeground();
                    rows.add(new String[]{pkg, String.valueOf(used), String.valueOf(limit)});
                }
                Collections.sort(rows, new Comparator<String[]>() {
                    @Override
                    public int compare(String[] a, String[] b) {
                        double ra = Long.parseLong(a[1]) / (Double.parseDouble(a[2]) * 60000.0);
                        double rb = Long.parseLong(b[1]) / (Double.parseDouble(b[2]) * 60000.0);
                        return Double.compare(rb, ra);
                    }
                });
            }
        } catch (Exception ignored) {}

        int[] icons = {R.id.l_a_icon, R.id.l_b_icon, R.id.l_c_icon};
        int[] names = {R.id.l_a_name, R.id.l_b_name, R.id.l_c_name};
        int[] times = {R.id.l_a_time, R.id.l_b_time, R.id.l_c_time};
        int[] bars = {R.id.l_a_bar, R.id.l_b_bar, R.id.l_c_bar};

        for (int i = 0; i < 3; i++) {
            if (i < rows.size()) {
                String pkg = rows.get(i)[0];
                long used = Long.parseLong(rows.get(i)[1]);
                int limit = Integer.parseInt(rows.get(i)[2]);
                int pct = (int) Math.min(100, used / (limit * 60000.0) * 100);
                v.setTextViewText(names[i], WidgetProvider.label(c, pkg));
                v.setTextViewText(times[i], WidgetProvider.dur(used) + " / " + limit + "m");
                v.setProgressBar(bars[i], 100, pct, false);
                android.graphics.Bitmap bm = WidgetProvider.icon(c, pkg);
                if (bm != null) v.setImageViewBitmap(icons[i], bm);
            } else {
                v.setTextViewText(names[i], i == 0 ? "No limits set" : "");
                v.setTextViewText(times[i], "");
                v.setProgressBar(bars[i], 100, 0, false);
            }
        }

        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.l_root, pi);
        return v;
    }
}
