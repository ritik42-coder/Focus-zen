package com.zenfocus.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** Home screen widget: today's screen time plus the two heaviest apps. */
public class WidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            try {
                manager.updateAppWidget(id, build(context));
            } catch (Exception ignored) {}
        }
    }

    public static void updateAll(Context context) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(context);
            ComponentName n = new ComponentName(context, WidgetProvider.class);
            int[] ids = m.getAppWidgetIds(n);
            for (int id : ids) m.updateAppWidget(id, build(context));
        } catch (Exception ignored) {}
    }

    static RemoteViews build(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_screen);
        long total = 0L;
        List<String[]> top = new ArrayList<>();   // {pkg, millis}
        try {
            UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm != null) {
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, 0);
                cal.set(Calendar.MINUTE, 0);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                Map<String, UsageStats> map =
                        usm.queryAndAggregateUsageStats(cal.getTimeInMillis(), System.currentTimeMillis());
                String self = c.getPackageName();
                List<UsageStats> list = new ArrayList<>(map.values());
                Collections.sort(list, new Comparator<UsageStats>() {
                    @Override
                    public int compare(UsageStats a, UsageStats b) {
                        return Long.compare(b.getTotalTimeInForeground(), a.getTotalTimeInForeground());
                    }
                });
                for (UsageStats s : list) {
                    if (s.getPackageName() == null || s.getPackageName().equals(self)) continue;
                    long ms = s.getTotalTimeInForeground();
                    if (ms < 60000L) continue;
                    total += ms;
                    if (top.size() < 2) top.add(new String[]{s.getPackageName(), String.valueOf(ms)});
                }
            }
        } catch (Exception ignored) {}

        int goal = 180;
        try {
            SharedPreferences p = c.getSharedPreferences("zenfocus", Context.MODE_PRIVATE);
            String json = p.getString("state", "");
            if (json != null && json.length() > 0) {
                goal = new JSONObject(json).optInt("goal", 180);
            }
        } catch (Exception ignored) {}

        int pct = goal > 0 ? (int) Math.min(100, total / (goal * 60000L) * 100) : 0;
        v.setTextViewText(R.id.w_total, dur(total));
        v.setTextViewText(R.id.w_sub, pct + "% of your " + goal / 60 + "h goal");
        v.setProgressBar(R.id.w_bar, 100, pct, false);

        int[] icons = {R.id.w_a_icon, R.id.w_b_icon};
        int[] names = {R.id.w_a_name, R.id.w_b_name};
        int[] times = {R.id.w_a_time, R.id.w_b_time};
        for (int i = 0; i < 2; i++) {
            if (i < top.size()) {
                String pkg = top.get(i)[0];
                long ms = Long.parseLong(top.get(i)[1]);
                v.setTextViewText(names[i], label(c, pkg));
                v.setTextViewText(times[i], dur(ms));
                Bitmap bm = icon(c, pkg);
                if (bm != null) v.setImageViewBitmap(icons[i], bm);
            } else {
                v.setTextViewText(names[i], i == 0 ? "No usage yet" : "");
                v.setTextViewText(times[i], "");
            }
        }

        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.w_root, pi);
        return v;
    }

    static String dur(long ms) {
        long m = Math.max(0, ms / 60000L);
        long h = m / 60, r = m % 60;
        if (h == 0) return r + "m";
        return h + "h" + (r > 0 ? " " + r + "m" : "");
    }

    static String label(Context c, String pkg) {
        try {
            return String.valueOf(c.getPackageManager().getApplicationLabel(
                    c.getPackageManager().getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    static Bitmap icon(Context c, String pkg) {
        try {
            Drawable d = c.getPackageManager().getApplicationIcon(pkg);
            int size = 96;
            Bitmap bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bm);
            d.setBounds(0, 0, size, size);
            d.draw(canvas);
            return bm;
        } catch (Exception e) {
            return null;
        }
    }
}
