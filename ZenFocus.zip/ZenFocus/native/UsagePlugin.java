package com.zenfocus.app;

import android.app.NotificationManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

/**
 * Zen Focus native bridge.
 *
 * Uses only Android framework + Capacitor core classes, so it compiles in any
 * Capacitor project without extra Gradle dependencies.
 */
@CapacitorPlugin(name = "Usage")
public class UsagePlugin extends Plugin {

    private UsageStatsManager usm() {
        return (UsageStatsManager) getContext().getSystemService(Context.USAGE_STATS_SERVICE);
    }

    private boolean hasUsageAccess() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                UsageStatsManager m = usm();
                if (m == null) return false;
                long now = System.currentTimeMillis();
                List<UsageStats> l = m.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 1000L * 60 * 60 * 6, now);
                return l != null && l.size() > 0;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean hasDndAccess() {
        try {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && nm.isNotificationPolicyAccessGranted();
        } catch (Exception e) {
            return false;
        }
    }

    @PluginMethod
    public void check(PluginCall call) {
        JSObject o = new JSObject();
        o.put("usage", hasUsageAccess());
        o.put("dnd", hasDndAccess());
        o.put("sdk", Build.VERSION.SDK_INT);
        call.resolve(o);
    }

    @PluginMethod
    public void openUsage(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void openDnd(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void setDnd(PluginCall call) {
        boolean on = Boolean.TRUE.equals(call.getBoolean("on", Boolean.FALSE));
        try {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.isNotificationPolicyAccessGranted()) {
                nm.setInterruptionFilter(on
                        ? NotificationManager.INTERRUPTION_FILTER_PRIORITY
                        : NotificationManager.INTERRUPTION_FILTER_ALL);
                call.resolve();
                return;
            }
        } catch (Exception ignored) {}
        call.reject("dnd not granted");
    }

    /** Foreground time per package between start and end (millis). */
    @PluginMethod
    public void usage(PluginCall call) {
        long start = call.getLong("start", 0L);
        long end = call.getLong("end", System.currentTimeMillis());
        JSArray arr = new JSArray();
        try {
            UsageStatsManager m = usm();
            if (m != null) {
                Map<String, UsageStats> map = m.queryAndAggregateUsageStats(start, end);
                String self = getContext().getPackageName();
                List<UsageStats> list = new ArrayList<>(map.values());
                Collections.sort(list, new Comparator<UsageStats>() {
                    @Override
                    public int compare(UsageStats a, UsageStats b) {
                        return Long.compare(b.getTotalTimeInForeground(), a.getTotalTimeInForeground());
                    }
                });
                for (UsageStats s : list) {
                    long ms = s.getTotalTimeInForeground();
                    if (ms < 1000) continue;
                    String pkg = s.getPackageName();
                    if (pkg == null || pkg.equals(self)) continue;
                    JSObject o = new JSObject();
                    o.put("pkg", pkg);
                    o.put("ms", ms);
                    o.put("last", s.getLastTimeUsed());
                    arr.put(o);
                }
            }
        } catch (Exception ignored) {}
        JSObject res = new JSObject();
        res.put("apps", arr);
        call.resolve(res);
    }

    /** Foreground time bucketed by hour of day (24 values), built from usage events. */
    @PluginMethod
    public void hourly(PluginCall call) {
        long start = call.getLong("start", 0L);
        long end = call.getLong("end", System.currentTimeMillis());
        long[] buckets = new long[24];
        try {
            UsageStatsManager m = usm();
            if (m != null) {
                UsageEvents ev = m.queryEvents(start, end);
                Map<String, Long> open = new HashMap<>();
                UsageEvents.Event e = new UsageEvents.Event();
                while (ev != null && ev.hasNextEvent()) {
                    ev.getNextEvent(e);
                    String p = e.getPackageName();
                    if (p == null) continue;
                    int type = e.getEventType();
                    long t = e.getTimeStamp();
                    if (type == UsageEvents.Event.ACTIVITY_RESUMED) {
                        open.put(p, t);
                    } else if (type == UsageEvents.Event.ACTIVITY_PAUSED
                            || type == UsageEvents.Event.ACTIVITY_STOPPED) {
                        Long s = open.remove(p);
                        if (s != null) addSpan(buckets, s, t, start);
                    }
                }
                for (Long s : open.values()) addSpan(buckets, s, end, start);
            }
        } catch (Exception ignored) {}
        JSArray arr = new JSArray();
        for (int i = 0; i < 24; i++) arr.put(buckets[i]);
        JSObject o = new JSObject();
        o.put("hours", arr);
        call.resolve(o);
    }

    /** Adds [from,to) to the hour buckets of the day that starts at dayStart. */
    private void addSpan(long[] buckets, long from, long to, long dayStart) {
        if (to <= from || dayStart <= 0L) return;
        long cur = Math.max(from, dayStart);
        while (cur < to) {
            long hourStart = dayStart + ((cur - dayStart) / 3600000L) * 3600000L;
            long segEnd = Math.min(to, hourStart + 3600000L);
            int h = (int) ((hourStart - dayStart) / 3600000L);
            if (h >= 0 && h < 24) buckets[h] += (segEnd - cur);
            cur = segEnd;
        }
    }

    /** Pickups / unlocks between start and end. */
    @PluginMethod
    public void events(PluginCall call) {
        long start = call.getLong("start", 0L);
        long end = call.getLong("end", System.currentTimeMillis());
        int pickups = 0, unlocks = 0;
        long first = 0L, last = 0L;
        try {
            UsageStatsManager m = usm();
            if (m != null) {
                UsageEvents ev = m.queryEvents(start, end);
                if (ev != null) {
                    UsageEvents.Event e = new UsageEvents.Event();
                    while (ev.hasNextEvent()) {
                        ev.getNextEvent(e);
                        int t = e.getEventType();
                        boolean isPickup = (t == UsageEvents.Event.SCREEN_INTERACTIVE);
                        boolean isUnlock = (t == UsageEvents.Event.KEYGUARD_HIDDEN);
                        if (isPickup) pickups++;
                        if (isUnlock) {
                            unlocks++;
                            long ts = e.getTimeStamp();
                            if (first == 0L || ts < first) first = ts;
                            if (ts > last) last = ts;
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
        JSObject o = new JSObject();
        o.put("pickups", pickups);
        o.put("unlocks", unlocks);
        o.put("first", first);
        o.put("last", last);
        call.resolve(o);
    }

    /** Launcher apps with labels and small PNG icons as data URLs. */
    @PluginMethod
    public void apps(PluginCall call) {
        JSArray arr = new JSArray();
        try {
            PackageManager pm = getContext().getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN, null);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
            Collections.sort(list, new Comparator<ResolveInfo>() {
                @Override
                public int compare(ResolveInfo a, ResolveInfo b) {
                    return String.valueOf(a.loadLabel(getContext().getPackageManager()))
                            .compareToIgnoreCase(String.valueOf(b.loadLabel(getContext().getPackageManager())));
                }
            });
            for (ResolveInfo ri : list) {
                try {
                    String pkg = ri.activityInfo.packageName;
                    JSObject o = new JSObject();
                    o.put("pkg", pkg);
                    o.put("label", String.valueOf(ri.loadLabel(pm)));
                    o.put("icon", iconData(ri.loadIcon(pm)));
                    try {
                        android.content.pm.ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                        o.put("cat", Build.VERSION.SDK_INT >= 26 ? ai.category : -1);
                        o.put("system", (ai.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0);
                    } catch (Exception ignored) {}
                    arr.put(o);
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        JSObject res = new JSObject();
        res.put("apps", arr);
        call.resolve(res);
    }


    /* ---------- persistent state (survives clearing web data) ---------- */

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences("zenfocus", Context.MODE_PRIVATE);
    }

    @PluginMethod
    public void saveState(PluginCall call) {
        String json = call.getString("json", "{}");
        try {
            prefs().edit().putString("state", json).apply();
            call.resolve();
        } catch (Exception e) {
            call.reject("save failed");
        }
    }

    @PluginMethod
    public void loadState(PluginCall call) {
        JSObject o = new JSObject();
        String s = "";
        try {
            s = prefs().getString("state", "");
        } catch (Exception ignored) {}
        o.put("json", s == null ? "" : s);
        call.resolve(o);
    }

    /* ---------- overlay + blocking guard ---------- */

    @PluginMethod
    public void hasOverlay(PluginCall call) {
        JSObject o = new JSObject();
        boolean granted = false;
        try {
            granted = Settings.canDrawOverlays(getContext());
        } catch (Exception ignored) {}
        o.put("granted", granted);
        call.resolve(o);
    }

    @PluginMethod
    public void openOverlay(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void startGuard(PluginCall call) {
        String limits = call.getString("limits", "{}");
        String strict = call.getString("strict", "{}");
        String allow = call.getString("allow", "[]");
        String block = call.getString("block", "[]");
        boolean student = Boolean.TRUE.equals(call.getBoolean("student", Boolean.FALSE));
        long until = call.getLong("studentUntil", 0L);
        long pauseUntil = call.getLong("pauseUntil", 0L);
        try {
            Intent i = new Intent(getContext(), BlockService.class);
            i.setAction(BlockService.ACTION_START);
            i.putExtra(BlockService.EXTRA_LIMITS, limits);
            i.putExtra(BlockService.EXTRA_STRICT, strict);
            i.putExtra(BlockService.EXTRA_ALLOW, allow);
            i.putExtra(BlockService.EXTRA_BLOCK, block);
            i.putExtra(BlockService.EXTRA_STUDENT, student);
            i.putExtra(BlockService.EXTRA_UNTIL, until);
            i.putExtra(BlockService.EXTRA_PAUSE, pauseUntil);
            if (Build.VERSION.SDK_INT >= 26) {
                getContext().startForegroundService(i);
            } else {
                getContext().startService(i);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot start guard: " + e.getMessage());
        }
    }

    /** Pushes fresh numbers into the home screen widget. */
    @PluginMethod
    public void refreshWidgets(PluginCall call) {
        try {
            WidgetProvider.updateAll(getContext());
        } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void stopGuard(PluginCall call) {
        try {
            Intent i = new Intent(getContext(), BlockService.class);
            i.setAction(BlockService.ACTION_STOP);
            getContext().startService(i);
        } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void requestNotify(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && getActivity() != null) {
                if (getContext().checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                        != PackageManager.PERMISSION_GRANTED) {
                    getActivity().requestPermissions(
                            new String[]{"android.permission.POST_NOTIFICATIONS"}, 91);
                }
            }
        } catch (Exception ignored) {}
        call.resolve();
    }

    /** Longest single session between start and end. */
    @PluginMethod
    public void longest(PluginCall call) {
        long start = call.getLong("start", 0L);
        long end = call.getLong("end", System.currentTimeMillis());
        String bestPkg = "";
        long best = 0L;
        try {
            UsageStatsManager m = usm();
            if (m != null) {
                UsageEvents ev = m.queryEvents(start, end);
                Map<String, Long> open = new HashMap<>();
                UsageEvents.Event e = new UsageEvents.Event();
                while (ev != null && ev.hasNextEvent()) {
                    ev.getNextEvent(e);
                    String p = e.getPackageName();
                    if (p == null) continue;
                    long t = e.getTimeStamp();
                    int type = e.getEventType();
                    if (type == UsageEvents.Event.ACTIVITY_RESUMED) {
                        open.put(p, t);
                    } else if (type == UsageEvents.Event.ACTIVITY_PAUSED
                            || type == UsageEvents.Event.ACTIVITY_STOPPED) {
                        Long s = open.remove(p);
                        if (s != null) {
                            long d = t - s;
                            if (d > best) {
                                best = d;
                                bestPkg = p;
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
        JSObject o = new JSObject();
        o.put("pkg", bestPkg);
        o.put("ms", best);
        call.resolve(o);
    }

    private String iconData(Drawable d) {
        try {
            int size = 72;
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            d.setBounds(0, 0, size, size);
            d.draw(c);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos);
            bmp.recycle();
            return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    /** Launch an app by package (used by the limit sheet). */
    @PluginMethod
    public void launch(PluginCall call) {
        String pkg = call.getString("pkg");
        if (pkg == null) { call.reject("pkg required"); return; }
        try {
            Intent i = getContext().getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) { call.reject("not found"); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot launch");
        }
    }

    /** Paints the real status / navigation bars. */
    @PluginMethod
    public void setBars(PluginCall call) {
        final String status = call.getString("status", "#0B0B0D");
        final String nav = call.getString("nav", "#0B0B0D");
        final boolean lightIcons = Boolean.TRUE.equals(call.getBoolean("light", Boolean.FALSE));
        if (getActivity() == null) { call.resolve(); return; }
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Window w = getActivity().getWindow();
                    w.setStatusBarColor(Color.parseColor(status));
                    w.setNavigationBarColor(Color.parseColor(nav));
                    View dv = w.getDecorView();
                    int flags = dv.getSystemUiVisibility();
                    if (lightIcons) {
                        flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    } else {
                        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    }
                    dv.setSystemUiVisibility(flags);
                } catch (Exception ignored) {}
            }
        });
        call.resolve();
    }
}
