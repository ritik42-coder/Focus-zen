# Zen Focus 2.1

Your own Digital Wellbeing: screen time, focus sessions, daily limits, a real block
screen, student mode and a home screen widget. On-device only.

## Get the APK (phone friendly)

1. Create a new GitHub repo.
2. **Add file → Create new file** → name it `.github/workflows/build-apk.yml`
   (the slashes create the folders) → paste `PASTE-THIS-WORKFLOW.yml` → Commit.
3. **Add file → Upload files** → upload `ZenFocus.zip` → Commit.
4. **Actions → Build APK** runs automatically, unzips the project and builds.
5. Open the green run → **Artifacts → ZenFocus-APK** → unzip → install `app-debug.apk`.

You only paste the workflow once. Everything else (native code, icons, permissions,
the widget) comes from inside the zip, so future versions are just a new zip upload.

## First launch

Grant **Usage access** (Settings → Special app access → Usage access → Zen Focus).
For blocking, allow **Display over other apps** on the Limits tab.

## What's inside

**Today** — screen time with a goal ring, pickups, unlocks, longest sit, an hourly
chart you can drag a finger across to read each hour, a category donut, and your most
used apps.

**Week** — seven-day bars, a 14-day trend, a 7×24 heatmap of when you pick the phone
up, and a balance score with a plain verdict.

**Focus** — 15/25/45/60 minute sessions with a live ring and optional Do Not Disturb.

**Limits** — daily budgets per app, plus three layers:

- **Soft limit** — full-screen "Time's up" with *Take a 5 minute break* or *Close app*.
- **Strict limit** — locked for 7 days, no break button, and the break window is
  cleared the moment strict is switched on. Cannot be edited until it expires.
- **Student mode** — blocks social, video and game apps for a chosen duration. Blocked
  apps get a study screen showing the apps that still work (calls, messages, WhatsApp,
  clock, calculator…) as a tappable grid. Calls and texts still ring.

**Widget** — a 4×2 home screen widget with today's screen time, your goal progress and
the two heaviest apps. Updates every 30 minutes and whenever the app refreshes.

**More** — six themes, eight accents, area/bar charts, live background, animations,
compact rows, 24-hour clock, daily goal, permission status.

## How blocking works

`BlockService` is a foreground service. Once a second it reads the foreground package
from `UsageEvents.ACTIVITY_RESUMED` and decides: student mode block first, then the
daily limit. The overlay is rebuilt whenever the rules change, so enabling strict mode
immediately removes the "5 minute break" escape.

Limits, strict locks and student mode are persisted through the plugin into
**SharedPreferences**, so clearing the app's web storage does not unlock them.

## Build notes

The workflow is deliberately thin: it copies `native/*.java` and `native/res/*` into the
Android project and runs `native/manifest_patch.py`, which adds the permissions, the
guard service and the widget receiver. That means the workflow itself rarely needs to
change — new features ship inside the zip.

Java files: `UsagePlugin` (all data + guard control), `BlockService` (enforcement),
`WidgetProvider` (home screen), `MainActivity` (registers the plugin). Only Android
framework and Capacitor core imports — no extra Gradle dependencies.

## Preview

Open `www/index.html` in a browser — it runs on generated sample data.
