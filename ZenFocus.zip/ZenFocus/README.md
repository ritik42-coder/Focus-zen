# Zen Focus 2.0

Your own Digital Wellbeing — screen time, focus sessions, daily limits, and a real
block screen when a limit runs out. On-device only: no account, no cloud, no tracking.

## Get the APK (phone friendly)

If you are doing this from your phone, you do **not** need to upload every file:

1. Create a new GitHub repo.
2. Add file → **Create new file** → name it `.github/workflows/build-apk.yml`
   (typing the slashes creates the folders) → paste the contents of `PASTE-THIS-WORKFLOW.yml`
   → Commit.
3. Add file → **Upload files** → upload `ZenFocus.zip` → Commit.
4. **Actions → Build APK** runs automatically and unzips the project itself.

On a computer you can instead upload this whole folder; the included
`.github/workflows/build-apk.yml` does the same thing.

## Get the APK

1. Put this folder in a GitHub repo (keep `.github/`). Uploading `ZenFocus.zip` alone works too.
2. **Actions → Build APK** runs on push, or press *Run workflow*.
3. Download the **ZenFocus-APK** artifact, unzip, install `app-debug.apk`.
4. Open the app → **Grant access** → Settings → Special app access → **Usage access** → Zen Focus → Allow.
5. For blocking: on the **Limits** tab tap **Allow** next to *Overlay permission* and enable
   "Display over other apps".

## What's inside

**Today** — screen time with a goal ring, pickups, unlocks, longest sit, an hour-by-hour
chart (area or bars, your choice), a category donut showing where the time goes, and your
most used apps.

**Week** — seven-day bars, a 14-day trend line comparing this week with last, a 7×24 heatmap
of when you actually pick the phone up, and a **balance score** with a plain-language verdict.

**Focus** — 15/25/45/60-minute sessions with a live ring and optional Do Not Disturb, plus a
session log.

**Limits** — a daily budget per app from 15m to 4h, search, and two levels of enforcement:

- **Soft** — the app is covered with a full-screen "Time's up" screen when you hit the limit,
  with *Take a 5 minute break* or *Close app*.
- **Strict** — lock the limit for 7 days. It cannot be changed or removed until the period
  ends, and the block screen drops the "take a break" escape hatch.

**More** — six themes, eight accents, area/bar charts, live background, animations,
compact rows, 24-hour clock, daily goal, permission status, reset.

## How blocking works

`BlockService` is a foreground service. Once a second it asks Android which app is in front
(`UsageEvents.ACTIVITY_RESUMED`), compares today's usage for that package against its limit,
and — if the limit is spent — draws a full-screen `TYPE_APPLICATION_OVERLAY` window over it
with the app's own icon. *Close app* sends the home intent, so you land on your launcher.

It needs **Display over other apps**. It does **not** need accessibility, so it installs and
behaves cleanly; the trade-off is that a determined user can dismiss the overlay by force
stopping Zen Focus or revoking the permission.

Limits and strict locks are also written to **SharedPreferences** through the native plugin,
so clearing the app's web storage does not unlock them.

## The logo

`native/res/mipmap-*` holds the launcher icons (a progress ring with a knob, indigo on near
black), generated at every density plus the adaptive foreground. The workflow copies them
over the Capacitor defaults.

## Build notes

Three Java files, all written by the workflow itself so the build never depends on files
being present in the repo: `UsagePlugin` (all the data), `BlockService` (the guard) and
`MainActivity` (registers the plugin). They import only Android framework and Capacitor core
classes — no extra Gradle dependencies, nothing that can fail to resolve.

Permissions added by the workflow: `PACKAGE_USAGE_STATS`, `ACCESS_NOTIFICATION_POLICY`,
`SYSTEM_ALERT_WINDOW`, `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_SPECIAL_USE`,
`POST_NOTIFICATIONS`, plus the `BlockService` declaration with its foreground-service type.

## Preview

Open `www/index.html` in a browser — it runs on generated sample data so you can feel the
motion and see every screen without a phone.
