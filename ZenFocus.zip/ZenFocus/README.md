# Zen Focus 2.1

Your own Digital Wellbeing: screen time, focus sessions, daily limits, a real block
screen, student mode and a home screen widget. On-device only.

## Get the APK (phone friendly)

1. Create a new GitHub repo.
2. **Add file → Create new file** → name it `.github/workflows/build-apk.yml`
   (the slashes create the folders) → paste `PASTE-THIS-WORKFLOW.yml` → Commit.
3. **Add file → Upload files** → upload `ZenFocus.zip` → Commit.
4. **Actions → Build APK** runs automatically, unzips the project and builds.
5. Open the green run → **Artifacts → ZenFocus-APK** → unzip → install `app-debug.apk`.

You only paste the workflow once. Everything else (native code, icons, permissions,
the widget) comes from inside the zip, so future versions are just a new zip upload.

## First launch

Grant **Usage access** (Settings → Special app access → Usage access → Zen Focus).
For blocking, allow **Display over other apps** on the Limits tab.

## What's inside

**Today** — screen time with a goal ring, pickups, unlocks, longest sit, an hourly
chart you can drag a finger across to read each hour, a category donut, and your most
used apps.

**Week** — seven-day bars, a 14-day trend, a 7×24 heatmap of when you pick the phone
up, and a balance score with a plain verdict.

**Focus** — 15/25/45/60 minute sessions with a live ring and optional Do Not Disturb.

**Limits** — daily budgets per app, plus three layers:

- **Soft limit** — full-screen "Time's up" with *Take a 5 minute break* or *Close app*.
- **Strict limit** — locked for 7 days, no break button, and the break window is
  cleared the moment strict is switched on. Cannot be edited until it expires.
- **Student mode** — pick a duration (30m / 45m / 1h / 1.5h / 2h or any custom number of
  minutes), choose exactly which apps are blocked and which stay allowed, and optionally
  turn on **strict study**, which cannot be ended until the timer runs out. Blocked apps
  get a study screen with a tappable grid of the apps that still work. A live countdown
  runs in the notification bar and on the Limits card.

**Notifications** — the guard posts a quiet notification with a live countdown while a
study block is running; tapping it opens the app.

**App detail** — tap any app to see its own screen: today, daily average, weekly total and
a seven-day bar chart, with quick actions for its limit, student mode and launching it.

**Insights & streaks** — generated lines on Today ("Instagram is 34% of today", "every
pickup is 42s", "down 8% vs last week") and a streak counter for days under your goal.

**Bedtime** — pick a window (default 22:00 → 07:00). Everything except your allowed apps
is covered with a "Time to rest" screen until morning.

**Widgets** — two home screen widgets: today's screen time with a goal bar and your two
heaviest apps, and a limits widget showing your three most-used limited apps. Both update
every 30 minutes and whenever the app refreshes.

**Share & export** — share a weekly summary card, or copy all usage as CSV.

**More** — six themes, eight accents, area/bar charts, live background, animations,
compact rows, 24-hour clock, daily goal, permission status.

## Motion

The interface reacts to how close you are to your limits. Under 80% everything is calm
indigo; from 80% the ring turns amber and the hero card warms; once an app is over, the
ring and card turn red, a soft red ambient glow fades in behind the UI, the screen-time
number breathes slowly and a pulsing "2 over limit" pill appears. All of it is
transform/opacity/colour only, so it stays at 60fps.

Tabs slide directionally (right for later tabs, left for earlier) with the cards staggering
in behind, the header shrinks and its subtitle fades as you scroll, sheets follow your finger
when you drag the handle and spring away past 90px, and the donut, bars and rings draw
themselves in on arrival. `Animations` off, or the system's reduce-motion setting, collapses
all of it to near-instant.

## How blocking works

`BlockService` is a foreground service. Once a second it reads the foreground package
from `UsageEvents.ACTIVITY_RESUMED` and decides: student mode block first, then the
daily limit. The overlay is rebuilt whenever the rules change, so enabling strict mode
immediately removes the "5 minute break" escape.

Limits, strict locks and student mode are persisted through the plugin into
**SharedPreferences**, so clearing the app's web storage does not unlock them.

## Build notes

The workflow is deliberately thin: it copies `native/*.java` and `native/res/*` into the
Android project and runs `native/manifest_patch.py`, which adds the permissions, the
guard service and the widget receiver. That means the workflow itself rarely needs to
change — new features ship inside the zip.

Java files: `UsagePlugin` (all data + guard control), `BlockService` (enforcement),
`WidgetProvider` (home screen), `MainActivity` (registers the plugin). Only Android
framework and Capacitor core imports — no extra Gradle dependencies.

## Preview

Open `www/index.html` in a browser — it runs on generated sample data.
